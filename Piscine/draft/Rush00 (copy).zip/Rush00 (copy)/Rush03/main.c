/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: halragga <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/03 16:55:16 by halragga          #+#    #+#             */
/*   Updated: 2025/01/04 13:02:50 by halragga         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	rush(int width, int hight);

void	print_line(int width);

void	print_col(int width, int height);

void	ft_putchar(char character);

void	print_point(void);

void	print_shape(int width, int height);

int	main(void)
{
	rush(18, -1);
	return (0);
}
